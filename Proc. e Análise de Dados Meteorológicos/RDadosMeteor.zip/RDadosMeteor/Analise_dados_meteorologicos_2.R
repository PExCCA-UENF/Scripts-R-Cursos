#==============================================================================#
#          EXTENSÃO UNIVERSITÁRIA EM CIÊNCIAS CLIMÁTICAS E AMBIENTAIS          #
#          PROJETO 'PROCESSAMENTO E ANÁLISE DE DADOS AMBIENTAIS COM R'         #
#                        Contato: pexcca.lamet@uenf.br                         #
#                       https://linktr.ee/pexcca.lamet                         #
#                       Script Atualizado em 11/11/2025                        #
#==============================================================================#
#        PROCESSAMENTO E ANÁLISE DE DADOS METEOROLÓGICOS NO R                 
#===============================================================================

# Objetivo: importar, tratar e visualizar dados meteorológicos (chuva e temperatura)
# utilizando a linguagem R.

#-------------------------------------------------------------------------------
# 1. INSTALAÇÃO DOS PACOTES NECESSÁRIOS (executar apenas uma vez)
#-------------------------------------------------------------------------------

# Esses pacotes contêm funções úteis para manipulação de dados e criação de gráficos.
install.packages(c("tidyverse", "readr", "ggtext"))

#-------------------------------------------------------------------------------
# 2. CARREGAMENTO DOS PACOTES
#-------------------------------------------------------------------------------

# Depois de instalar, precisamos carregar os pacotes para que suas funções fiquem disponíveis.
library(tidyverse)   # Conjunto de pacotes para manipulação e visualização de dados.
library(readr)       # Leitura de arquivos com diferentes formatos.
library(ggtext)      # Permite usar HTML no título dos gráficos.

#-------------------------------------------------------------------------------
# 3. IMPORTAÇÃO DOS DADOS
#-------------------------------------------------------------------------------

# Lê um arquivo CSV separado por ponto e vírgula, com datas e horas formatadas.
dados <- read_delim("generatedBy_react-csv.csv", 
                    delim = ";",
                    col_types = cols(
                      Data = col_date(format = "%d/%m/%Y"),
                      `Hora (UTC)` = col_time(format = "%H%M")
                    ), 
                    locale = locale(decimal_mark = ",", grouping_mark = "."), 
                    trim_ws = TRUE)

# Visualiza a estrutura dos dados importados:
glimpse(dados)

#-------------------------------------------------------------------------------
# 4. FILTRAGEM DOS DADOS PARA O MÊS DE OUTUBRO
#-------------------------------------------------------------------------------

# Seleciona apenas os registros do mês de outubro:
dados_outubro <- filter(dados, format(Data, "%m") == "10")

# Cria uma nova coluna combinando data e hora em um único campo:
dados_outubro <- mutate(dados_outubro, 
                        Data_Hora = ymd_hms(paste(Data, `Hora (UTC)`)), 
                        .before = Data)

# Visualiza os dados filtrados
View(dados_outubro)

#-------------------------------------------------------------------------------
# 5. GRÁFICO DE PRECIPITAÇÃO
#-------------------------------------------------------------------------------

# Vamos visualizar:
#   A taxa de precipitação (chuva por hora).
#   A precipitação acumulada diária.

# Calcula a precipitação acumulada por dia e gera o gráfico:
gr1 <- dados_outubro |> 
  group_by(Data) |> 
  mutate(Chuva_acum = cumsum(`Chuva (mm)`)) |> 
  ggplot(aes(x = Data_Hora)) +
  geom_col(aes(y = `Chuva (mm)`, fill = "Taxa de Precipitação (mm)")) +
  geom_line(aes(y = Chuva_acum, color = "Precipitação Acumulada Diária (mm)"), linewidth = 1) +
  scale_fill_manual(values = "steelblue") +
  scale_color_manual(values = "red3") +
  scale_x_datetime(breaks = "1 day", date_labels = "%d/%m") +
  labs(x = "", y = "Precipitação (mm)", 
       title = "Precipitação: <span style='color:#4682B4;'>Taxa Precipitação(mm)</span>; <span style='color:#CD0000;'>Acumulada Diária (mm)</span>", 
       color = "", fill = "") +
  theme_minimal() +
  theme(
    plot.title = element_markdown(),
    legend.position = "bottom",
    axis.text.x = element_text(size = 9, angle = 90)
  )

gr1

# Exercício: # Altere a cor da linha de precipitação acumulada para "darkgreen" e observe o resultado.

#-------------------------------------------------------------------------------
# 6. GRÁFICO DE TEMPERATURA
#-------------------------------------------------------------------------------

# Reorganiza os dados de temperatura para facilitar a visualização:
Temp_outubro <- dados_outubro |>
  select(Data_Hora:`Temp. Min. (C)`) |>
  pivot_longer(cols = `Temp. Ins. (C)`:`Temp. Min. (C)`, 
               names_to = "Var", 
               values_to = "Temp")

# Visualiza os dados reorganizados:
View(Temp_outubro)

# Cria o gráfico de temperatura:
gr2 <- Temp_outubro |>
  ggplot(aes(x = Data_Hora, y = Temp, color = Var)) +
  geom_line(linewidth = 1) +
  scale_color_manual(values = c("red3", "orange3", "steelblue")) +
  scale_x_datetime(breaks = "1 day", date_labels = "%d/%m") +
  labs(x = "", y = "Temperatura (ºC)", 
       title = "Temperatura: <span style='color:#cd0000;'>Máx (ºC)</span>, <span style='color:#cd8500;'>Ins (ºC)</span>, <span style='color:#4682b4;'>Min (ºC)</span>", 
       color = "") +
  theme_minimal() +
  theme(
    plot.title = element_markdown(),
    legend.position = "bottom",
    axis.text.x = element_text(size = 9, angle = 90)
  )

gr2

# Exercício: Crie um gráfico apenas com a temperatura mínima. 
# Dica: use filter() para selecionar apenas "Temp. Min. (C)" antes de plotar.

#-------------------------------------------------------------------------------
# 7. SALVANDO O GRÁFICO EM UM ARQUIVO
#-------------------------------------------------------------------------------

# Salva o gráfico de temperatura como imagem PNG
ggsave(plot = gr1, 
       filename = "Prec.png",
       width = 9, height = 5, units = "in", bg = "#FCF9F7")

#------------------------https://linktr.ee/pexcca.lamet------------------------#
# Acessar: https://pexcca-uenf.shinyapps.io/ShinyApp-MeteoGrafR/